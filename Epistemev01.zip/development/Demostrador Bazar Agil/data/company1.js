{"company" : 
  {
    "name" : "Company 1",
    "logo" : { "text" : "company 1 logo", "src" : "data/images/logo1.png"},
    "description" : "The description of first company",
    "capabilities" : [ "technical_memo", "admin_memo" ]
  }
}
