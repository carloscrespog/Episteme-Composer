{"offer" :
  {
    "name" : "Oferta chachi",
    "logo" : { "text" : "offer 1 logo", "src" : "data/images/logo1.png"},
    "description" : "This offer will doesn't look pretty well",
    "capabilities" : [ "money_maker", "search_engine_optmizator","admin_memo" ]
  }
}