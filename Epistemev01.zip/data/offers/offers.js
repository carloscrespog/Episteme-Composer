{"offers": [{
	"name" : "Offer 1",
	"logo" : { "text" : "company 4 logo", "src" : "data/images/offer4.png"},
	"description" : "The description of fourth company",
	"capabilities" : [ "Pequeña y mediana empresa", "Universidad","Otros" ]

},{
	"name" : "Offer 2",
	"logo" : { "text" : "company 3 logo", "src" : "data/images/offer3.png"},
	"description" : "The description of third company",
	"capabilities" : [ "Gran Empresa","Centro Tecnológico","Pequeña y mediana empresa" ]

},{
	"name" : "Offer 3",
	"logo" : { "text" : "company 2 logo", "src" : "data/images/offer5.png"},
	"description" : "The description of second company",
	"capabilities" : [ "Centro Privado de Investigación","Asociación de Empresa"  ]

}


]}