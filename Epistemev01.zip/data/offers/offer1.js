{"offer" :
  {
    "name" : "Oferta chachi",
    "logo" : { "text" : "offer 1 logo", "src" : "data/images/logo1.png"},
    "description" : "This offer will make you ride the dollar",
    "capabilities" : [ "technical_memo", "admin_memo" ]
  }
}