{"offer": [{"skill":"Base de datos SQL", "level":"Intermedio"}, {"skill":"JavaScript", "level":"Experto"}, {"skill":"Java", "level":"Avanzado"}, {"skill":"Sistemas Inteligentes", "level":"Intermedio"}],
"candidates":
  [{"company":"Global Metanoia", "global_value":0.9, 
    "results" : [{"skill":"Oracle", "level":"Experto", "value":0.69}, 
                 {"skill":"VBScript", "level":"Experto", "value":0.9509}, 
                 {"skill":"VisualBasic", "level":"Experto", "value":0.6702},
                 {"skill":"Sistemas Inteligentes", "level":"Basico", "value":0.4702}]},
   {"company":"Paradigma Tecnologico", "global_value":0.75, 
    "results" : [{"skill":"Oracle", "level":"Experto", "value":1}, 
                 {"skill":"VBScript", "level":"Intermedio", "value":0.55}, 
                 {"skill":"VisualBasic", "level":"Avanzado", "value":0.7},
                 {"skill":"Machine Learning", "level":"Experto", "value":0.6702}]},
   {"company":"Universidad Politécnica de Madrid", "global_value":0.59, 
    "results" : [{"skill":"Oracle", "level":"Experto", "value":0.27888}, 
                 {"skill":"VBScript", "level":"Experto", "value":0.531}, 
                 {"skill":"VisualBasic", "level":"Experto", "value":0.79},
                 {"skill":"Sistemas QA", "level":"Experto", "value":0.6702}]},
   {"company":"Consultoría Informática Neonetronic", "global_value":0.295,
    "results" : [{"skill":"Oracle", "level":"Básico", "value":0.29}, 
                 {"skill":"VBScript", "level":"Experto", "value":0.155}, 
                 {"skill":"VisualBasic", "level":"Intermedio", "value":0.17},
                 {"skill":"Sistemas QA", "level":"Experto", "value":0.6702}]}
  ]
}
