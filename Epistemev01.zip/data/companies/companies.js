{"companies": [{
	"name" : "Company 1",
	"logo" : { "text" : "company 4 logo", "src" : "data/images/logo4.png"},
	"description" : "The description of fourth company",
	"capabilities" : [ "economical_memo", "admin_memo" ]

},{
	"name" : "Company 2",
	"logo" : { "text" : "company 3 logo", "src" : "data/images/logo3.png"},
	"description" : "The description of third company",
	"capabilities" : [ "economical_memo" ]

},{
	"name" : "Company 3",
	"logo" : { "text" : "company 2 logo", "src" : "data/images/logo2.png"},
	"description" : "The description of second company",
	"capabilities" : [ "technical_memo" ]

},{
	"name" : "Company 4",
	"logo" : { "text" : "company 1 logo", "src" : "data/images/logo1.png"},
	"description" : "The description of first company",
	"capabilities" : [ "technical_memo", "admin_memo" ]
}


]}