{"company" : 
  {
    "name" : "Company 3",
    "logo" : { "text" : "company 3 logo", "src" : "data/images/logo3.png"},
    "description" : "The description of second company",
    "capabilities" : [ "economical_memo" ]
  }
}
