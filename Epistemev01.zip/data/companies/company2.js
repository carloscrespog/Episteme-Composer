{"company" : 
  {
    "name" : "Company 2",
    "logo" : { "text" : "company 2 logo", "src" : "data/images/logo2.png"},
    "description" : "The description of second company",
    "capabilities" : [ "technical_memo" ]
  }
}
